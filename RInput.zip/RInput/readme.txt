- RInput 1.31 -

RInput allows you to override low definition windows mouse input (accurate until 400cpi)
with high definition mouse input (raw input, which is more accurate for high cpi mice).


Advantages:
�����������
- Prevents negative acceleration
- More accurate
- Bypass windows mouse settings (1:1, Low Level)
- Less overhead than Direct Input


How to use:
�����������
- Start RInput.exe from windows explorer.
- Provide the name of the executable (in this case: hl.exe)

In case you run RInput from dos prompt you have to provide the
executable by command line.
 
Note: if the process is not running, RInput will wait for
the process to be in running state.
