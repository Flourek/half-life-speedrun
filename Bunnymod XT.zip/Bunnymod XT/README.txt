Bunnymod XT - developed by YaLTeR
----------------------------------------------------
BXT is an external injection software for the GoldSource Engine that provides additional speedrun-related features such as in-game timer, speed info etc.
It is also a platform for creating tool-assisted speedruns.

How to install:
----------------------------------------------------
Simply extract the 'Bunnymod XT' folder anywhere on your hard drive, for example "C:\Tools\Bunnymod XT"

How to use:
----------------------------------------------------
1. Make sure that BunnymodXT.dll and Injector.exe are always in the same location/folder
2. Launch Half-Life (hl.exe)
3. Launch the injector (Injector.exe; if you're on Windows 7 make sure you run as administrator)

Note: If you receive any errors about missing DLLs, launch the vc_redist.x86.exe to get them.

How to update:
----------------------------------------------------
1. Go to https://github.com/YaLTeR
2. If the Injector needs updating, go to BunnymodXT-Injector repository
3. Click 'Releases', the download links are here
4. If the DLL needs updating, go to BunnymodXT repository
5. Click 'Releases', the download links are here

Useful Commands
----------------------------------------------------
bxt_timer_reset - Resets the timer
bxt_timer_stop - Pauses the timer
bxt_timer_start - Begins or resumes the timer
bxt_timer_autostop <0-1> - Toggles the automatic stopping of the timer at the end of a full-game run (only works in HL1, OP4, BShift and GMC)

bxt_hud_timer <0-1> - Toggles the timer display
bxt_hud_speedometer <0-1> - Toggles the speedometer display
bxt_hud_jumpspeed <0-1> - Toggles the jumpspeed display

See BXT Wiki for more info/commands: https://github.com/YaLTeR/BunnymodXT/wiki